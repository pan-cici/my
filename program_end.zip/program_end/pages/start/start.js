// pages/start/start.js
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    setInter: '',
    num:0,
    username: null,
    password: null, //所有根内容
    button:[
      "开始测试",
      "暂时停止",
      "上传结果",
      "查看答案",
      "",
      "继续运行"
    ],
    bu:["start","stop","end","check","null1","rend"],
    zt:null,
    zt1:null,
    x1:null,
    x2:null,
    t:null,
    xx:["+","-","*","/"],
    d:null,
    ansr:null,
    ansuser: [null, null, null, null, null, null, null, null, null, null],
    tu:null,
    xianshi:null,
    flag:false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //监听是否登录
    if (app.appData.userdata == null) {
      wx.redirectTo({
        url: '/pages/woring/woring',
      })
    } else {
      this.setData({
        username: app.appData.userdata.username,
        password: app.appData.userdata.password,
        zt:[this.data.bu[0],this.data.button[0]],
        zt1:[this.data.bu[4],this.data.button[4]],
      })
    }
    //一打开页面就加载browserroot
    


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  jisuan:function(a,b,c){
    var x1 = parseInt(a);
    var x2 = parseInt(c);
    switch (b){
      case "+":
        return parseInt(x1+x2);
      case "-":
        return parseInt(x1-x2);
      case "*":
        return parseInt(x1*x2);
      case "/":
        return parseInt(x1/x2);
    }
  },


  read: function (e) {
    app.appData.pid = e.target.dataset.id //获取replay按钮上的id
    wx.navigateTo({
      url: '/pages/reply/reply',

    })
  },
  startSetInter: function () {
    var that = this;
    that.data.setInter = setInterval(
      function () {
        var numv = that.data.num+1;
        that.setData({
          num:numv,
        })
        //函数
      }, 1000);
  },
  endSetInter: function () {
    var that = this;
    //清除计时器  即清除setInter
    clearInterval(that.data.setInter)
  },

  start: function () {
    this.startSetInter();

    this.setData({
      zt:  [this.data.bu[1], this.data.button[1]],
      zt1: [this.data.bu[2], this.data.button[2]],
      x1: [
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
      ],
      x2:[
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
        Math.floor(Math.random() * 99 + 1),
      ],
      t:[
        this.data.xx[Math.floor(Math.random() * 4)],
        this.data.xx[Math.floor(Math.random() * 4)],
        this.data.xx[Math.floor(Math.random() * 4)],
        this.data.xx[Math.floor(Math.random() * 4)],
        this.data.xx[Math.floor(Math.random() * 4)],
        this.data.xx[Math.floor(Math.random() * 4)],
        this.data.xx[Math.floor(Math.random() * 4)],
        this.data.xx[Math.floor(Math.random() * 4)],
        this.data.xx[Math.floor(Math.random() * 4)],
        this.data.xx[Math.floor(Math.random() * 4)],
      ],
      d: ["=", "=", "=", "=", "=", "=", "=", "=", "=", "="]
    })

    var x1 = this.data.x1;
    var x2 = this.data.x2;
    var t = this.data.t;
    var that = this;
    this.setData({
      ansr:[
        that.jisuan(x1[0], t[0], x2[0]),
        that.jisuan(x1[1], t[1], x2[1]),
        that.jisuan(x1[2], t[2], x2[2]),
        that.jisuan(x1[3], t[3], x2[3]),
        that.jisuan(x1[4], t[4], x2[4]),
        that.jisuan(x1[5], t[5], x2[5]),
        that.jisuan(x1[6], t[6], x2[6]),
        that.jisuan(x1[7], t[7], x2[7]),
        that.jisuan(x1[8], t[8], x2[8]),
        that.jisuan(x1[9], t[9], x2[9]),
      ]
    })
  },
  stop: function(){
    this.endSetInter();
    this.setData({
      zt: [this.data.bu[5], this.data.button[5]],
      zt1: [this.data.bu[2], this.data.button[2]],
      flag:true,
    })
  },

  rend: function () {
    this.startSetInter();
    this.setData({
      zt: [this.data.bu[1], this.data.button[1]],
      zt1: [this.data.bu[2], this.data.button[2]],
      flag: false,
    })
   },
  
  end:function(e){
    this.endSetInter();
    this.setData({
      zt: [this.data.bu[3], this.data.button[3]],
      zt1: [this.data.bu[4], this.data.button[4]],
      
    })
    

  },
  check:function(){
    var that = this;
    var tu = [];
      tu[0] = that.bijiao(this.data.ansuser[0], this.data.ansr[0]),
      tu[1] = that.bijiao(this.data.ansuser[1], this.data.ansr[1]),
      tu[2] = that.bijiao(this.data.ansuser[2], this.data.ansr[2]),
      tu[3] = that.bijiao(this.data.ansuser[3], this.data.ansr[3]),
      tu[4] = that.bijiao(this.data.ansuser[4], this.data.ansr[4]),
      tu[5] = that.bijiao(this.data.ansuser[5], this.data.ansr[5]),
      tu[6] = that.bijiao(this.data.ansuser[6], this.data.ansr[6]),
      tu[7] = that.bijiao(this.data.ansuser[7], this.data.ansr[7]),
      tu[8] = that.bijiao(this.data.ansuser[8], this.data.ansr[0]),
      tu[9] = that.bijiao(this.data.ansuser[9], this.data.ansr[9]),

    this.setData({
      tu:tu,
      xianshi:this.data.ansr,
      flag:false,
    })
  },
  null1:function(){},
  ans0:function(e){
    console.log(e.detail.value);
    var a = e.detail.value;
    var ansuser = "ansuser[0]";
    if (this.data.zt[0]!="check"){
    this.setData({
      [ansuser]:a,
    })
    }
  },
  ans1: function (e) {
    console.log(e.detail.value);
    var a = e.detail.value;
    var ansuser = "ansuser[1]";
    if (this.data.zt[0] != "check") {
      this.setData({
        [ansuser]:a,
      })
    }
    return a;
  },
  ans2: function (e) {
    console.log(e.detail.value);
    var a = e.detail.value;
    var ansuser = "ansuser[2]";
    if (this.data.zt[0] != "check") {
      this.setData({
        [ansuser]:a,
      })
    }
  },
  ans3: function (e) {
    console.log(e.detail.value);
    var a = e.detail.value;
    var ansuser = "ansuser[3]";
    if (this.data.zt[0] != "check") {
      this.setData({
        [ansuser]:a,
      })
    }
  },
  ans4: function (e) {
    console.log(e.detail.value);
    var a = e.detail.value;
    var ansuser = "ansuser[4]";
    if (this.data.zt[0] != "check") {
      this.setData({
        [ansuser]:a,
      })
    }
  },
  ans5: function (e) {
    console.log(e.detail.value);
    var a = e.detail.value;
    var ansuser = "ansuser[5]";
    if (this.data.zt[0] != "check") {
      this.setData({
        [ansuser]:a,
      })
    }
  },
  ans6: function (e) {
    console.log(e.detail.value);
    var a = e.detail.value;
    var ansuser = "ansuser[6]";
    if (this.data.zt[0] != "check") {
      this.setData({
        [ansuser]:a,
      })
    }
  },
  ans7: function (e) {
    console.log(e.detail.value);
    var a = e.detail.value;
    var ansuser = "ansuser[7]";
    if (this.data.zt[0] != "check") {
      this.setData({
        [ansuser]:a,
      })
    }
  },
  ans8: function (e) {
    console.log(e.detail.value);
    var a = e.detail.value;
    var ansuser = "ansuser[8]";
    if (this.data.zt[0] != "check") {
      this.setData({
        [ansuser]:a,
      })
    }
  },
  ans9: function (e) {
    console.log(e.detail.value);
    var a = e.detail.value;
    var ansuser = "ansuser[9]";
    if (this.data.zt[0] != "check") {
      this.setData({
        [ansuser]:a,
      })
    }
  },
  bijiao:function(a,b){
    var x1 = parseInt(a);
    var x2 = parseInt(b);
    if (x1==x2){
      return "right"
    }else{
      return "error"
    }

  }





})